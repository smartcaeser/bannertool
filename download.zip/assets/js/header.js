var $canvas = new Canvas('canvas');


function render(){
  $canvas.render();
}